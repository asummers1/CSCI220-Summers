module.exports = { 
    rules: {
        'no-console': 'off', //Used to enable console.log in the editor
    },
};